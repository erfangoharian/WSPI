% Defination of U to X function
function X=X_value(U,mu,sigma,distri)
switch distri
    case 'TruncNormal'
        X=mu+sigma*norminv((1-normcdf(-mu/sigma))*U+normcdf(-mu/sigma));
    case 'LogNormal'
        X=exp(norminv(U)*sqrt(log(1+sigma^2/(mu^2)))+log(mu)-0.5*log(1+sigma^2/(mu^2)));
    case 'TruncGumbel'
        a=1.282549808/sigma;
        b=mu-(0.5772156649/a);
        X=b-log(-log(U*(1-exp(-exp(a*b)))+exp(-exp(a*b))))/a;
    case 'Weibull'
        k=k_solveWeibull(mu,sigma);
        u=mu/gamma(1+1/k);
        X=u*(-log(1-U)).^(1/k);
end
return
