%%%%%%%%%%%%%%%%Estimate WSPI for new data values%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% by Erfan Goharian
%%%%%%%%%%%%%%%%%%%%%%%% 2015, University of Utah


% clc;
% clear
format short;
randn('state',1);

%% Builidng the copula

% Load data of Reliability (X1) and Vulnerability (X2)
data=xlsread('data.xlsx');


% Select the type of Copula
Type_Copula='Gaussian';

% Calculate Size of data, mean, and standard deviation of data
[rows cols]=size(data);
mu=mean(data);
sigma=std(data);

% Pearson's linear correlation coefficient
Pearson_data=corr(data);


% Kendall's tau
Kendall_data=corr(data,'type','Kendall');

% Estimation of copula parameters

switch Type_Copula
    case 'Gaussian'
        rho=sin(pi/2*Kendall_data);
        display(rho)
    case 'Plackett'
        theta_Plackett=theta_estimationPlackett_Kendall(Kendall_data(1,2));
        dsiplay(theta)
    case 'Frank'
        theta_Frank=copulaparam('Frank',Kendall_data(1,2),'type','Kendall');
        dsiplay(theta)
    case 'No.16'
        theta_16=theta_estimation16_Kendall(Kendall_data(1,2));
        dsiplay(theta)
end


%% Generate random numbers form Copula

% Number of realization
N=10000;

z=randn(N,2);
zz=z*inv(chol(cov(z)));
switch Type_Copula
    case 'Gaussian'
        Q=chol(rho);
        Y=zz*Q;
        U=normcdf(Y);
    case 'Plackett'
        V=normcdf(zz);
        U=zeros(size(V));
        U(:,1)=V(:,1);
        a=V(:,2).*(1-V(:,2));
        b=theta+a.*(theta-1)^2;
        c=2*a.*(U(:,1).*theta^2+1-U(:,1))+theta.*(1-2.*a);
        d=sqrt(theta).*sqrt(theta+4.*a.*U(:,1).*(1-U(:,1)).*(1-theta)^2);
        U(:,2)=(c-(1-2.*V(:,2)).*d)./(2.*b);
    case 'Frank'
        V=normcdf(zz);
        U=zeros(size(V));
        U(:,1)=V(:,1);
        U(:,2)=-1/theta.*log(1+V(:,2).*(1-exp(-theta))./(V(:,2).*(exp(-theta.*U(:,1))-1)-ezp(-theta.*U(:,1))));
    case 'No.16'
        V=normcdf(zz);
        U=zeros(size(V));
        U(:,1)=V(:,1);
        for m=1:N
            U(m,2)=U2_solve16(U(m,1),V(m,2),theta);
        end
end

%Mean of U
mu_U=mean(U);
display(mu_U);

% Pearson's linear correlation coefficient
Pearson_U=corr(U);
display(Pearson_U);

% Kendall's tau
Kendall_U=corr(U,'type','Kendall');
display(Kendall_U);

%% Simulation of Reliability and Vulnerability from constructed joint probablity

% Marginal distributions of data
distri(1,1)={'LogNormal'};
distri(1,2)={'LogNormal'};

X=zeros(size(U));
for m=1:2
    X(:,m)=X_value(U(:,m),mu(m),sigma(m),distri{1,m});
end

% Pearson's linear correlation coefficient
Pearson_X=corr(X);
display(Pearson_X);

% Kendall's tau
Kendall_X=corr(X,'type','Kendall');
display(Kendall_X);


%% Estimate WSPI

prompt = 'What is the reliability value? ';
X(N+1,1) = input(prompt);
prompt = 'What is the vulnerbaility value? ';
X(N+1,2) = input(prompt);

[datasort,dataindex]=sort(X);
Ranks_data=X;
for m=1:cols
    Ranks_data(dataindex(:,m),m)=1:N+1;
end
UU=Ranks_data/(N+1+1);


F1 = copulacdf('Gaussian',[UU(N+1,1) 1],rho);
F2 = copulacdf('Gaussian',[UU(N+1,1) UU(N+1,2)],rho);
WSPI=F1-F2;
display(WSPI);
