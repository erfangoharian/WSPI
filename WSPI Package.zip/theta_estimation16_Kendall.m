%%%%

%Definition of No.16 copula's dependence parameter estimation function

function y=theta_estimation16_Kendall(tau)
a=1e-6;
b=1e4;
eps=1e-6;
fx=@(theta,tau)1+4*quadgk(@(t)(theta./t+1).*(1-t)./(theta./t.^2.*(t-1)-(theta./t+1)),0,1)-tau;
fa=fx(a,tau);
fb=fx(b,tau);
if fa*fb>0
    disp('error:[a b] interval no soloution, please re-enter a and b');
    return
end
while b-a>eps
    c=0.5*(a+b);
    fc=fx(c,tau);
    if (fc*fa<0)
        b=c;
        fb=fc;
    else
        a=c;
        fa=fc;
    end
end
y=0.5*(a+b);
return
