%%%%%%%%%%%%%%%%%%%%%%%%%Identification of best-fit margins and copula
%%%%%%%%%%%%%%%%%%%%%%%%%using AIC and BIC
%%%%%%%%%%%%%%%%%%%%%%%% by Erfan Goharian
%%%%%%%%%%%%%%%%%%%%%%%% 2015, University of Utah


clc;
clear;
format short;

%Read observed Reliability (X1) and Vulnerability (X2)
[num,txt,raw] = xlsread('data1.xlsx','sheet1');
%combine data as you want:
data=num;

Rel=data(:,1);
Vul=data(:,2);
Scenarios=txt(:,1);%as you want

figure(1);
scatterhist(Rel,Vul)
hold on
gscatter(Rel,Vul,Scenarios)

% Calculate Size of data, mean, and standard deviation of data > rows,
% cols, mu, sigma
[rows cols]=size(data);
mu=mean(data);
sigma=std(data);

% Number of distribution parameters, Parameter_Margin
Parameter_Margin=2;

% figure;
% scatterhist(Rel,Vul)

%% Select best-fit margin among Normal, LogNormal, Gubmel, and Weibull distributions

% Calculate AIC and BIC values for Relaibility (X1)
%TruncNormal
PDF_TruncNormal_X1=normpdf(data(:,1),mu(1),sigma(1))/(1-normcdf(-mu(1)/sigma(1)));
AIC_TruncNormal_X1=abs(-2*sum(log(PDF_TruncNormal_X1))+2*Parameter_Margin);
BIC_TruncNormal_X1=abs(-2*sum(log(PDF_TruncNormal_X1))+log(rows)*Parameter_Margin);

%LogNormal
sLn=sqrt(log(1+(sigma(1)/mu(1))^2));
mLn=log(mu(1))-sLn^2/2;
PDF_LogNormal_X1=lognpdf(data(:,1),mLn,sLn);
AIC_LogNormal_X1=abs(-2*sum(log(PDF_LogNormal_X1))+2*Parameter_Margin);
BIC_LogNormal_X1=abs(-2*sum(log(PDF_LogNormal_X1))+log(rows)*Parameter_Margin);

%TruncGumbel
a=1.282549808/sigma(1);
b=mu(1)-(0.5772156649/a);
PDF_TruncGumbel_X1=a*exp(-a*(data(:,1)-b)-exp(-a*(data(:,1)-b)))/(1-exp(-exp(a*b)));
AIC_TruncGumbel_X1=abs(-2*sum(log(PDF_TruncGumbel_X1))+2*Parameter_Margin);
BIC_TruncGumbel_X1=abs(-2*sum(log(PDF_TruncGumbel_X1))+log(rows)*Parameter_Margin);

%Weibull
k=k_solveWeibull(mu(1),sigma(1));
u=mu(1)/gamma(1+1/k);
PDF_Weibull_X1=k/u*(data(:,1)/u).^(k-1).*exp(-(data(:,1)/u).^k);
AIC_Weibull_X1=abs(-2*sum(log(PDF_Weibull_X1))+2*Parameter_Margin);
BIC_Weibull_X1=abs(-2*sum(log(PDF_Weibull_X1))+log(rows)*Parameter_Margin);

AIC_X1=[AIC_TruncNormal_X1 AIC_LogNormal_X1 AIC_TruncGumbel_X1 AIC_Weibull_X1];

display(AIC_X1);
[AIC_min_X1 Index_X1]=min(AIC_X1, [],2);
if Index_X1== 1
    display('The best-fit margin for X1 using AIC is TruncNormal distribution');
elseif Index_X1== 2
    display('The best-fit margin for X1 using AIC is LogNormal distribution');
elseif Index_X1== 3
    display('The best-fit margin for X1 using AIC is TruncGumbel distribution');
elseif Index_X1== 4
    display('The best-fit margin for X1 using AIC is Weibull distribution');
end

BIC_X1=[BIC_TruncNormal_X1 BIC_LogNormal_X1 BIC_TruncGumbel_X1 BIC_Weibull_X1];

display(BIC_X1);
[BIC_min_X1 Index_X1]=min(BIC_X1, [],2);
if Index_X1== 1
    display('The best-fit margin for X1 using BIC is TruncNormal distribution');
elseif Index_X1== 2
    display('The best-fit margin for X1 using BIC is LogNormal distribution');
elseif Index_X1== 3
    display('The best-fit margin for X1 using BIC is TruncGumbel distribution');
elseif Index_X1== 4
    display('The best-fit margin for X1 using BIC is Weibull distribution');
end


% Calculate AIC and BIC values for Vulnerability (X2)
%TruncNormal
PDF_TruncNormal_X2=normpdf(data(:,2),mu(2),sigma(2))/(1-normcdf(-mu(2)/sigma(2)));
AIC_TruncNormal_X2=abs(-2*sum(log(PDF_TruncNormal_X2))+2*Parameter_Margin);
BIC_TruncNormal_X2=abs(-2*sum(log(PDF_TruncNormal_X2))+log(rows)*Parameter_Margin);

%LogNormal
sLn=sqrt(log(1+(sigma(2)/mu(2))^2));
mLn=log(mu(2))-sLn^2/2;
PDF_LogNormal_X2=lognpdf(data(:,2),mLn,sLn);
AIC_LogNormal_X2=abs(-2*sum(log(PDF_LogNormal_X2))+2*Parameter_Margin);
BIC_LogNormal_X2=abs(-2*sum(log(PDF_LogNormal_X2))+log(rows)*Parameter_Margin);

%TruncGumbel
a=1.282549808/sigma(2);
b=mu(2)-(0.5772156649/a);
PDF_TruncGumbel_X2=a*exp(-a*(data(:,2)-b)-exp(-a*(data(:,2)-b)))/(1-exp(-exp(a*b)));
AIC_TruncGumbel_X2=abs(-2*sum(log(PDF_TruncGumbel_X2))+2*Parameter_Margin);
BIC_TruncGumbel_X2=abs(-2*sum(log(PDF_TruncGumbel_X2))+log(rows)*Parameter_Margin);

%Weibull
k=k_solveWeibull(mu(2),sigma(2));
u=mu(2)/gamma(1+1/k);
PDF_Weibull_X2=k/u*(data(:,2)/u).^(k-1).*exp(-(data(:,1)/u).^k);
AIC_Weibull_X2=abs(-2*sum(log(PDF_Weibull_X2))+2*Parameter_Margin);
BIC_Weibull_X2=abs(-2*sum(log(PDF_Weibull_X2))+log(rows)*Parameter_Margin);

AIC_X2=[AIC_TruncNormal_X2 AIC_LogNormal_X2 AIC_TruncGumbel_X2 AIC_Weibull_X2];

display(AIC_X2);
[AIC_min_X2 Index_X2]=min(abs(AIC_X2), [],2);
if Index_X2== 1
    display('The best-fit margin for X2 using AIC is TruncNormal distribution');
elseif Index_X2== 2
    display('The best-fit margin for X2 using AIC is LogNormal distribution');
elseif Index_X2== 3
    display('The best-fit margin for X2 using AIC is TruncGumbel distribution');
elseif Index_X2== 4
    display('The best-fit margin for X2 using AIC is Weibull distribution');
end

BIC_X2=[BIC_TruncNormal_X2 BIC_LogNormal_X2 BIC_TruncGumbel_X2 BIC_Weibull_X2];

display(BIC_X2);
[BIC_min_X2 Index_X2]=min(abs(BIC_X2), [],2);
if Index_X2== 1
    display('The best-fit margin for X2 using BIC is TruncNormal distribution');
elseif Index_X2== 2
    display('The best-fit margin for X2 using BIC is LogNormal distribution');
elseif Index_X2== 3
    display('The best-fit margin for X2 using BIC is TruncGumbel distribution');
elseif Index_X2== 4
    display('The best-fit margin for X2 using BIC is Weibull distribution');
end


%% Select the best-fit copula among Gaussian, Plackett, Frank and N0.16

% copulas from Empirical distributations of data (U)
[datasort,dataindex]=sort(data);
Ranks_data=data;
for m=1:cols
    Ranks_data(dataindex(:,m),m)=1:rows;
end
U=Ranks_data/(rows+1);

% Kendall's tau of data
Kendall_data=corr(data,'type','Kendall');

% Estimate the copula parameters
rho_Gaussian=sin(pi/2*Kendall_data);
theta_Plackett=theta_estimationPlackett_Kendall(Kendall_data(1,2));
theta_Frank=copulaparam('Frank',Kendall_data(1,2),'type','Kendall');
theta_16=theta_estimation16_Kendall(Kendall_data(1,2));
Copula_parameter=[rho_Gaussian(1,2) theta_Plackett theta_Frank theta_16];
display(Copula_parameter);

% Number of copula parameters
Parameter_Copula=1;
cPlackett=@(u,v,theta)((1+(theta-1)*(u+v))^2-4*u*v*theta*(theta-1))^(-3/2)*theta*(1+(theta-1)*(u+v-2*u*v)); %for Plackett
c16=@(u,v,theta)0.5*(1+theta/u^2)*(1+theta/v^2)*((u+v-1-theta*(1/u+1/v-1))^2+4*theta)^(-0.5)*(-((u+v-1-theta*(1/u+1/v-1))^2+4*theta)^(-1)*(u+v-1-theta*(1/u+1/v-1))^2+1); %for N0.16

% Calculate the AIC and BIC for copulas

% Gaussian
PDF_Gaussian=copulapdf('Gaussian',U,rho_Gaussian(1,2));
AIC_Gaussian=abs(-2*sum(log(PDF_Gaussian))+2*Parameter_Copula);
BIC_Gaussian=abs(-2*sum(log(PDF_Gaussian))+log(rows)*Parameter_Copula);

% Plackett
PDF_Plackett=zeros(rows,1);
for m=1:rows
    PDF_Plackett(m)=cPlackett(U(m,1),U(m,2),theta_Plackett);
end
AIC_Plackett=abs(-2*sum(log(PDF_Plackett))+2*Parameter_Copula);
BIC_Plackett=abs(-2*sum(log(PDF_Plackett))+log(rows)*Parameter_Copula);

% Frank
PDF_Frank=copulapdf('Frank',U,theta_Frank);
AIC_Frank=abs(-2*sum(log(PDF_Frank))+2*Parameter_Copula);
BIC_Frank=abs(-2*sum(log(PDF_Frank))+log(rows)*Parameter_Copula);

%No.16
PDF_16=zeros(rows,1);
for m=1:rows
    PDF_16(m)=c16(U(m,1),U(m,2),theta_16);
end
AIC_16=abs(-2*sum(log(PDF_16))+2*Parameter_Copula);
BIC_16=abs(-2*sum(log(PDF_16))+log(rows)*Parameter_Copula);

AIC_Copula=[AIC_Gaussian AIC_Plackett AIC_Frank AIC_16];
display(AIC_Copula);
[AIC_min_Copula Index_Copula]=min(AIC_Copula,[],2);
if Index_Copula== 1
    display('The best-fit margin for Copula using AIC is Gaussian distribution');
elseif Index_Copula== 2
    display('The best-fit margin for Copula using AIC is Plackett distribution');
elseif Index_Copula== 3
    display('The best-fit margin for Copula using AIC is Frank distribution');
elseif Index_Copula== 4
    display('The best-fit margin for Copula using AIC is No.16 distribution');
end

BIC_Copula=[BIC_Gaussian BIC_Plackett BIC_Frank BIC_16];
display(BIC_Copula);
[BIC_min_Copula Index_Copula]=min(abs(BIC_Copula),[],2);
if Index_Copula== 1
    display('The best-fit margin for Copula using BIC is Gaussian distribution');
elseif Index_Copula== 2
    display('The best-fit margin for Copula using BIC is Plackett distribution');
elseif Index_Copula== 3
    display('The best-fit margin for Copula using BIC is Frank distribution');
elseif Index_Copula== 4
    display('The best-fit margin for Copula using BIC is No.16 distribution');
end


