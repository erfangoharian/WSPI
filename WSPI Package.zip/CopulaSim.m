%%%%%%%%%%%%%%%%Simulation of copulas and bivariate distribution
%%%%%%%%%%%%%%%%%%%%%%%% by Erfan Goharian
%%%%%%%%%%%%%%%%%%%%%%%% 2015, University of Utah


clc;
clear
format short;
randn('state',1);

% Load data of Reliability (X1) and Vulnerability (X2)
data=xlsread('data1.xlsx');

% Number of realization
N=1000;

% Select the type of Copula
prompt = 'Select the type of Copula [Gaussian, Plackett, Frank]: ';
str = input(prompt,'s');
Type_Copula=str;

% Marginal distributions of data
distri(1,1)={'LogNormal'};
distri(1,2)={'LogNormal'};

% Seeds fixed at 1
randn('state',1);

% Calculate Size of data, mean, and standard deviation of data
[rows cols]=size(data);
mu=mean(data);
sigma=std(data);

% Pearson's linear correlation coefficient
Pearson_data=corr(data);
display(Pearson_data);

% Kendall's tau
Kendall_data=corr(data,'type','Kendall');
display(Kendall_data);

% Estimation of copula parameters
switch Type_Copula
    case 'Gaussian'
        rho=sin(pi/2*Kendall_data);
        display(rho)
    case 'Plackett'
        theta_Plackett=theta_estimationPlackett_Kendall(Kendall_data(1,2));
        dsiplay(theta)
    case 'Frank'
        theta_Frank=copulaparam('Frank',Kendall_data(1,2),'type','Kendall');
        dsiplay(theta)
    case 'No.16'
        theta_16=theta_estimation16_Kendall(Kendall_data(1,2));
        dsiplay(theta)
end


%% Simulation of correlated uniformly distributed variables from copulas
z=randn(N,2);
zz=z*inv(chol(cov(z)));
switch Type_Copula
    case 'Gaussian'
        Q=chol(rho);
        Y=zz*Q;
        U=normcdf(Y);
    case 'Plackett'
        V=normcdf(zz);
        U=zeros(size(V));
        U(:,1)=V(:,1);
        a=V(:,2).*(1-V(:,2));
        b=theta+a.*(theta-1)^2;
        c=2*a.*(U(:,1).*theta^2+1-U(:,1))+theta.*(1-2.*a);
        d=sqrt(theta).*sqrt(theta+4.*a.*U(:,1).*(1-U(:,1)).*(1-theta)^2);
        U(:,2)=(c-(1-2.*V(:,2)).*d)./(2.*b);
    case 'Frank'
        V=normcdf(zz);
        U=zeros(size(V));
        U(:,1)=V(:,1);
        U(:,2)=-1/theta.*log(1+V(:,2).*(1-exp(-theta))./(V(:,2).*(exp(-theta.*U(:,1))-1)-ezp(-theta.*U(:,1))));
    case 'No.16'
        V=normcdf(zz);
        U=zeros(size(V));
        U(:,1)=V(:,1);
        for m=1:N
            U(m,2)=U2_solve16(U(m,1),V(m,2),theta);
        end
end

%Mean of U
mu_U=mean(U);
%display(mu_U);

% Pearson's linear correlation coefficient
Pearson_U=corr(U);
%display(Pearson_U);

% Kendall's tau
Kendall_U=corr(U,'type','Kendall');
%display(Kendall_U);

% Scatter plots of U
figure (1);
scatter(U(:,1),U(:,2),'.','b');
if (Kendall_data(1,2)>0)
    legend('Simulated data for U','Location','SouthEast');
else
    legend('Simulated data for U','Location','SouthWest');
end
axis([-0.05 1.05 -0.05 1.05]);
box on
xlabel('{\it U}_1','fontname','Times New Roman');
ylabel('{\it U}_2','fontname','Times New Roman');


%% Simulation of Reliability and Vulnerability from constructed joint probablity
X=zeros(size(U));
for m=1:2
    X(:,m)=X_value(U(:,m),mu(m),sigma(m),distri{1,m});
end

% Pearson's linear correlation coefficient
Pearson_X=corr(X);
%display(Pearson_X);

% Kendall's tau
Kendall_X=corr(X,'type','Kendall');
%display(Kendall_X);

% Scatter plots of X
figure (2);
scatter(X(:,1),X(:,2),'.','b');
if (Kendall_data(1,2)>0)
    legend('Simulated data for X','Location','SouthEast');
else
    legend('Simulated data for X','Location','SouthWest');
end
axis([-0.05 1.05 -0.05 1.05]);
box on
xlabel('{\it Rel}_1','fontname','Times New Roman');
ylabel('{\it Vul}_2','fontname','Times New Roman');

%% % Plot Probability Density and CDF (Gaussian)
[datasort,dataindex]=sort(data);
Ranks_data=data;
for m=1:cols
    Ranks_data(dataindex(:,m),m)=1:rows;
end
UU=Ranks_data/(rows+1);


u1 = linspace(1e-3,1-1e-3,50);
u2 = linspace(1e-3,1-1e-3,50);
[U1,U2] = meshgrid(u1,u2);
f = copulapdf('Gaussian',[U1(:) U2(:)],rho);
f = reshape(f,size(U1));

figure(3)
surf(u1,u2,log(f),'FaceColor','interp','EdgeColor','none')
view([-15,20])
xlabel('U1')
ylabel('U2')
zlabel('Probability Density')

figure(4)
contour(u1,u2,log(f), 'ShowText','on')
% hold on
% scatter(UU(:,1),UU(:,2));
hold on 
scatter(U(:,1),U(:,2),'.','b');


u1 = linspace(1e-3,1-1e-3,50);
u2 = linspace(1e-3,1-1e-3,50);
[U1,U2] = meshgrid(u1,u2);
F = copulacdf('Gaussian',[U1(:) U2(:)],rho);
F = reshape(F,size(U1));

figure(5)
surf(u1,u2,F,'FaceColor','interp','EdgeColor','none')
view([-15,20])
xlabel('U1')
ylabel('U2')
zlabel('Cumulative Probability')

figure(6)
contour(u1,u2,F, 'ShowText','on')
% hold on
% scatter(UU(:,1),UU(:,2));
hold on 
scatter(U(:,1),U(:,2),'.','b');
