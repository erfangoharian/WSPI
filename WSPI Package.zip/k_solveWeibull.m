%%% 

% Definiation of Weibull distribution parameter k

function y=k_solveWeibull(mu,sigma)
a=0.02;
b=40;
eps=1e-6;
fa=1/sqrt(gamma(1+2/a)/gamma(1+1/a)^2-1)-mu/sigma;
fb=1/sqrt(gamma(1+2/b)/gamma(1+1/b)^2-1)-mu/sigma;
if fa*fb>0
    disp('error:[a b]interval no soloutionplease re-enter a and b');
    return
end
while b-a>eps
    c=0.5*(a+b);
    fc=1/sqrt(gamma(1+2/c)/gamma(1+1/c)^2-1)-mu/sigma;
    if fc*fa<0
        b=c;
        fb=fc;
    else
        a=c;
        fa=fc;
    end
end
y=0.5*(a+b);
return
