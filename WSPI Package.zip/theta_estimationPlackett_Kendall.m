%%%%

%Definition of Plackett copula's dependence parameter estimation function

function y=theta_estimationPlackett_Kendall(tau)
a=1e-6;
b=1e4;
eps=1e-6;
fx=@(theta,tau)4*dblquad(@(u,v)(1+(theta-1).*(u+v)-sqrt((1+(theta-1).*(u+v)).^2-4.*u.*v.*theta.*(theta-1)))./2./(theta-1).*((1+(theta-1).*(u+v)).^2-4.*u.*v.*theta.*(theta-1)).^(-3/2).*theta.*(1+(theta-1).*(u+v-2.*u.*v)),0,1,0,1)-1-tau;
fa=fx(a,tau);
fb=fx(b,tau);
if fa*fb>0
    disp('error:[a b] interval no soloution, please re-enter a and b');
    return
end
while b-a>eps
    c=0.5*(a+b);
    fc=fx(c,tau);
    if (fc*fa<0)
        b=c;
        fb=fc;
    else
        a=c;
        fa=fc;
    end
end
y=0.5*(a+b);
return

